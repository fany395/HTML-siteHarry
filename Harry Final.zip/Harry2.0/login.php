<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<?php
include './db/controlelogin.php';


if (!empty($_POST['nome'])) {
    
	$email = $_POST['email'];
	$senha = $_POST['senha'];
	
}
?>
<html xmlns="https://www.w3.org/1999/xhtml" lang="pt-br"> 
<head>
    <meta charset="UTF-8" />
    <meta name="viwport" content="whidth=device-width, initial-scale=1"/>
    <title>Hogwarts</title>
    <meta name="keywords" content="escola, matrículas, bruxaria, Harry Potter"/>
    <meta name="author" content=" Ana Caroline Ferreira, Ana Clara Sabino, Sthefany Silva e Reyanne Fernandes"/>
    <audio src="midia/Harry Potter song.mp3" autoplay loop ></audio>
    <link rel= "shortcut icon" href="midia/logo.png" type="x-png"/>
    <link rel="stylesheet" type="text/css"  href=" css/style.css"/>
    <link rel= "stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
    <link rel="icon" href="midia/logo.png">
    
</head>
<body>

        <header class="cabecalho">
                <a href="#"><h1 class="logo">Hogwarts</h1></a>
                <button class="btn-menu"><i class="fa fa-bars fa-lg"></i></button>
                <nav class="menu">
                    <a class="btn-close"><i class="fa fa-times"></i></a>
                    <ul>
                        <li> <a href="index.html">Início</a></li>
                        <li> <a href="cursos.html">Cursos</a></li>
                        <li><a href="história.html">História</a></li>
                        <li> <a href="login.html">Portal do aluno</a></li>
                        
                </ul>
                </nav>
                
                </header>
    <div class="box">
        <article class="fundo">
                <div class="loginBox">  
                         <form action="controlelogin.php">
                                <h2>Login</h2>
                                
                                    <p>Email</p>
                                    <input type="text" name = "" placeholder=" Email">
                                    <p>Password</p>
                                    <input type="password" name = "" placeholder="Senha">
                                    <input type="submit" class = "btn" value="Entrar">
                                    <p>OU</p>  
                                  <input  type="submit" class = "btn" value="Cadastre-se">
                                    
                               </form>
                                 </div>
                        
            </article>
        </div>
   

    <footer class="rodape">
            <div class="social-icons">
                <a href="#"> <i class="fa fa-facebook"></i></a>
                <a href="#"> <i class="fa fa-instagram"></i></a>
                <a href="#"> <i class="fa fa-whatsapp"></i></a>
            </div>
                <p class="copyright">copyright © Hogwarts 2019. Todos os direitos reservados</p>
        </footer> 
    <script src="http://code.jquery.com/jquery-1.12.0.min.js"></script>
    <script>
        $(".btn-menu").click(function(){
           $(".menu").show();
        });
        $(".btn-close").click(function(){
           $(".menu").hide();
        });
       </script> 
    </body>
</html>
            
    