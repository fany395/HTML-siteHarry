<?php

include './db/conecta.php';



function createUser( $conn, $nome, $nascimento,$rg, $cpf, $curso,$cep,$rua,$numero,$bairro,$cidade,$estado, $email, $senha, $confirmarS){
$result = mysqli_query ($conn, "INSERT INTO matricula (nome, nascimento, rg, cpf, curso, cep,  rua, numero, bairro, cidade,estado, email, senha,confirmarS) VALUES('$nome','$nascimento','$rg','$cpf','$curso','$cep','$rua','$numero','$bairro','$cidade','$estado','$email','$senha','$confirmarS')");

	return $result;
}
