<?php
$to = $email;
$subject = 'Bem vindo a Hogwarts!';
$message = 'Futuro bruxo sua matricula em Hogwarts foi efetuada com sucesso.
Logo sua carta chegara!

Atenciosamente
 Dumbledore';


$headers = 'From: webmaster@example.com' . "\r\n" .
    'Reply-To: webmaster@example.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

mail($to, $subject, $message, $headers);
?> 