<?php 
// Conexão com o banco de dados 
include './db/conecta.php'; 
include './db/controle.php';
session_start();

if ((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) == true)) {
	unset($_SESSION['email']);
	unset($_SESSION['senha']);
	unset($_SESSION['nome']);
	//header('location:index.php');
} else {
	$logado = $_SESSION['email'];
}

 
$result = mysqli_query($conn, "SELECT * FROM matricula
WHERE 'email' = '$email' AND 'senha' = '$senha'");
	if (mysqli_num_rows($result) > 0) {
		$dadosUser = mysqli_fetch_assoc($result);

		$_SESSION['email'] = $email;
		$_SESSION['senha'] = $senha;
		



		?>
		<div class="alert alert-success text-center" role="alert">
			<?php echo "Logado com sucesso!";
			header('location:./index.html');
			?>
		</div>

	<?php
} else {
	unset($_SESSION['email']);
	unset($_SESSION['senha']);

	?>
		<div class="alert alert-danger text-center" role="alert">
			<?php echo "Dados inválidos. Tente novamente!"; ?>
		</div>
	<?php
}

?>