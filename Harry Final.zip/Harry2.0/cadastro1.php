<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<?php
include './db/controle.php';


if (!empty($_POST['nome'])) {
    $nome = $_POST['nome'];
	$nascimento = $_POST['nascimento'];
    $rg = $_POST['rg'];
    $cpf = $_POST['cpf'];
	$curso = $_POST['curso'];
    $cep = $_POST['cep'];
    $rua = $_POST['rua'];
    $numero = $_POST['numero'];
    $bairro = $_POST['bairro'];
    $cidade = $_POST['cidade'];
    $estado = $_POST['estado'];
	$email = $_POST['email'];
	$senha = $_POST['senha'];
	$confirmarS = $_POST['confirmarS'];

	$result = createUser($conn, $nome, $nascimento,$rg, $cpf, $curso,$cep,$rua,$numero,$bairro,$cidade,$estado, $email, $senha, $confirmarS);
	

		if ($result == 0) {
		?>
		<div class="alert alert-danger text-center" role="alert">
			<script type="application/javascript">
                alert("Erro ao Cadastrar.Cpf ou email já cadastrado!")
            </script>
                </div>
	<?php
} else {
            include './db/email.php';
            $email=$_POST['email'];
	?>
		
    <?php header('location:login.php');?>

	<?php
}
}
?>
<html xmlns="https://www.w3.org/1999/xhtml" lang="pt-br"> 
<html> 
<head>
    <meta charset="UTF-8" />
    <meta name="viwport" content="whidth=device-width, initial-scale=1"/>
    <title>Hogwarts</title>
    <meta name="author" content=" Ana Caroline Ferreira, Ana Clara Sabino, Sthefany Silva e Reyanne Fernandes"/>
    <audio src="midia/Harry Potter song.mp3" autoplay loop ></audio>
    <link rel= "shortcut icon" href="midia/logo.png" type="x-png"/>
    <link rel="stylesheet" type="text/css"  href=" css/style.css"/>
    <link rel="stylesheet" type="text/css"  href=" css/cadastro-style.css"/>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel= "stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
    <link rel="icon" href="midia/logo.png"/>
        
<script src="https://code.jquery.com/jquery-3.2.1.min.js"
                integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
                crossorigin="anonymous"></script>
    
        <!-- Adicionando Javascript -->
        <script type="text/javascript" >
    
            $(document).ready(function() {
    
                function limpa_formulário_cep() {
                    // Limpa valores do formulário de cep.
                    $("#rua").val("");
                    $("#bairro").val("");
                    $("#cidade").val("");
                    $("#uf").val("");
                    
                }
                
                //Quando o campo cep perde o foco.
                $("#cep").blur(function() {
    
                    //Nova variável "cep" somente com dígitos.
                    var cep = $(this).val().replace(/\D/g, '');
    
                    //Verifica se campo cep possui valor informado.
                    if (cep != "") {
    
                        //Expressão regular para validar o CEP.
                        var validacep = /^[0-9]{8}$/;
    
                        //Valida o formato do CEP.
                        if(validacep.test(cep)) {
    
                            //Preenche os campos com "..." enquanto consulta webservice.
                            $("#rua").val("...");
                            $("#bairro").val("...");
                            $("#cidade").val("...");
                            $("#uf").val("...");
                            
    
                            //Consulta o webservice viacep.com.br/
                            $.getJSON("https://viacep.com.br/ws/"+ cep +"/json/?callback=?", function(dados) {
    
                                if (!("erro" in dados)) {
                                    //Atualiza os campos com os valores da consulta.
                                    $("#rua").val(dados.logradouro);
                                    $("#bairro").val(dados.bairro);
                                    $("#cidade").val(dados.localidade);
                                    $("#uf").val(dados.uf);
                                  
                                } //end if.
                                else {
                                    //CEP pesquisado não foi encontrado.
                                    limpa_formulário_cep();
                                    alert("CEP não encontrado.");
                                }
                            });
                        } //end if.
                        else {
                            //cep é inválido.
                            limpa_formulário_cep();
                            alert("Formato de CEP inválido.");
                        }
                    } //end if.
                    else {
                        //cep sem valor, limpa formulário.
                        limpa_formulário_cep();
                    }
                });
            });
            </script>
               <link rel="stylesheet" 
                     crossorigin="anonymous"
                     href="http://gc.kis.v2.scr.kaspersky-labs.com/A73DDFEC-F11C-EC41-B595-7337BA3B89D9/abn/main.css">
    
      <script type="text/javascript" >
    /* Máscaras ER */
    
    function mascara(o,f){
        v_obj=o
        v_fun=f
        setTimeout("execmascara()",1)
    }
    function execmascara(){
        v_obj.value=v_fun(v_obj.value)
    }
    function mtel(v){
        v=v.replace(/D/g,"");             //Remove tudo o que não é dígito
        v=v.replace(/^(d{2})(d)/g,"($1) $2"); //Coloca parênteses em volta dos dois primeiros dígitos
        v=v.replace(/(d)(d{4})$/,"$1-$2");    //Coloca hífen entre o quarto e o quinto dígitos
        return v;
    }
    function id( el ){
      return document.getElementById( el );
    }
    window.onload = function(){
      id('telefone').onkeypress = function(){
        mascara( this, mtel );
      }
    }
    
    </script>

<script>
        function validaSenha (input){ 
          if (input.value != document.getElementById('senha').value) {
            input.setCustomValidity('Repita a senha corretamente');
          } else {
            input.setCustomValidity('');
          }
        } 
        </script>
       
</head>
<body>

        <header class="cabecalho">
                <a href="#"><h1 class="logo">Hogwarts</h1></a>
                <div class="buttons">
                        <a href="index.html"><button class="btn-matricula">VOLTAR</button></a>
                        </div>    
            </header>         
            <div class="box">
                
                    <article class="fundo">
                            <div class="inner">
                                    <h2>Faça sua matrícula</h2>
                            </div>
                    </article>
                                     <!-- Inicio do formulario -->
                                  
              <form name="matricula"  method="post">
                    <article class="fundo">
                            <div class="inner"> 
                               
                                    <div class="loginBox-c"> 
                                            
                                                         
                                              
                                                           <h2>Dados Pessoais</h2>
                                                  
                                                           <fieldset>
                                                      <p>Nome Completo:</p>
                                                  <input type="text"  pattern="[a-zA-Z\s]+$" 
                                                    title="Somente letras" name="nome"  required/>
                                                      <p>Nascimento:</p><input  tabindex="3" 
                                                     type="date" 
                                                     pattern="[0-9]{2}\/[0-9]{2}\/[0-9]{4}$" 
                                                     min="01-01-1900" name="nascimento" required />
                                                      <p>RG:</p><input type="text" maxlength="15" size="15" name="rg" required/>
                                                  <p>CPF:</p><input  type="text" tabindex="2" 
                                                     maxlength="14" 
                                                     placeholder="000.000.000-00"
                                                     pattern="\d{3}\.\d{3}\.\d{3}-\d{2}" 
                                                     title="Insira o cpf no formato 123.456.789-00" 
                                                     name="cpf" required />
                                                
                                                  <p>Curso:</p> <select name="curso" required>
       		
                                                         <option value="Herbologia">Herbologia </option>
                                                         <option value="Vôo">Vôo </option>
                                                         <option value="Astronomia">Astronomia </option>
                                                         <option value="Aritmancia">Aritmancia </option>
                                                         <option value="Runas Antigas">Runas Antigas </option>
                                                         <option value="Adivinhação">Adivinhação </option>
                                                         <option value="Trato das Criaturas">Trato das Criaturas Mágicas </option>
                                                         <option value="Defesa Contra AS artes das trevas">Defesa Contra as Artes das Trevas  </option>
                                                         <option value="Estudos dos Trouxas">Estudo dos Trouxas </option>
                                                         <option value="História da Magia">História da Magia</option>
                                                         <option value="Feitiços">Feitiços  </option>
                                                         <option value="Transfigurações">Transfigurações</option>


                                                    </select><br>
                  
                                                 
                              
                                              </fieldset>
                                        
                                              </div>
                            </div>
                    </article>
                                     
                                              <article class="fundo">
                                                    <div class="inner">
                                                            <div class="loginBox-c"> 
                                                                                                             
                                                             <h2>Dados de Endereço</h2>
                                                             <fieldset>
                                                  <p>CEP:</p><input  id="cep" type="text" maxlength="8" size="8" required=""  pattern="[0-9]+$"
                                                  placeholder="00000-000" name="cep"/><br>
                                                     <p>Rua:</p><input id="rua" type="text" name="rua"required />
                                                  <p>Número: </p><input  type="text" maxlength="10" size="10" name="numero"/>
                                                     <p>Bairro:</p><input  id="bairro" type="text" name="bairro"required/>
                                                  <p>Cidade:</p><input id="cidade" type="text" name="cidade" required/>
                                                    <p>Estado:</p>
                                                  
                                                      <select id= "uf" name="estado"  required>
                                             
                                                              <option value="AC">Acre </option>
                                                              <option value="AL">Alagoas </option>
                                                              <option value="AP">Amapá </option>
                                                              <option value="AM">Amazonas </option>
                                                              <option value="BA">Bahia </option>
                                                              <option value="CE">Ceará </option>
                                                              <option value="DF">Distrito Federal </option>
                                                              <option value="ES">Espiríto Santo </option>
                                                              <option value="GO">Goiás </option>
                                                              <option value="MA">Maranhão </option>
                                                              <option value="MT">Mato Grosso </option>
                                                              <option value="MS">Mato Grosso do Sul </option>
                                                              <option value="MG">Minas Gerais </option>
                                                              <option value="PA">Pará </option>
                                                              <option value="PB">Paraíba </option>
                                                              <option value="PR">Paraná </option>
                                                              <option value="PE">Pernambuco </option>
                                                              <option value="PI">Piauí </option>
                                                              <option value="RJ">Rio de Janeiro </option>
                                                              <option value="RN">Rio Grande do Norte </option>
                                                              <option value="RS">Rio Grande do Sul </option>
                                                              <option value="RO">Rondônia </option>
                                                               <option value="RR">Roraima </option>
                                                               <option value="SC">Santa Catarina </option>
                                                               <option value="SP">São Paulo </option>
                                                               <option value="SE">Sergipe </option>
                                                               <option value="TO">Tocantins </option>
                                                               <option value="ES">Estrangeiro </option>       		
                                                          
                                                         </select>
                                                         </fieldset>
                                                                
                                                         </div>
                                                         </div>
                                                        </article>

                                                     <article class="fundo">
                                                            <div class="inner">
                                                                    <div class="loginBox-c"> 
                                                                           
                                                         
                                                                         
                                                              <h2>Dados de Login</h2>
                                                              <fieldset>
                                                              <p>Email:</p><input  type="email" 
                                                     pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" 
                                                     tabindex="5" placeholder="blabla@email.com" name="email" required />
                                                   <p>Senha:</p><input  id="senha" type="password" size="15" maxlength="15" placeholder="************" name="senha" required/><br>
                                                   <p>Confirmar Senha:</p><input  id="confimarS" type="password"size="15" 
                                                      maxlength="15" placeholder="************"  oninput="validaSenha(this)"name="confirmarS" required />
                              
                                                         </fieldset>
                                                                       
                                                         </div>
                                                         </div>
                                                          <input  type="submit" value="Enviar"/>
                                                         <input  type="reset" value="cancelar"/>
                                                        </article>

        
                                                 
                </form>
    </div>

            <footer class="rodape">
                    <div class="social-icons">
                        <a href="#"> <i class="fa fa-facebook"></i></a>
                        <a href="#"> <i class="fa fa-instagram"></i></a>
                        <a href="#"> <i class="fa fa-whatsapp"></i></a>
                    </div>
                        <p class="copyright">copyright © Hogwarts 2019. Todos os direitos reservados</p>
                </footer> 
                

</body>
</html>